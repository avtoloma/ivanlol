<?php
class Tovap_model extends CI_Model
{
    public function tovap_insert($naming, $age, $rarity, $era, $price)
    {
        $sql = "INSERT INTO `klu`(`naming`, `age`, `rarity`, `era`, `price`) VALUES (?,?,?,?,?)";
        $result = $this->db->query($sql, array($naming, $age, $rarity, $era, $price));
        return $this->db->insert_id();
    }

    public function lick_add(){
        $sql = "SELECT * FROM `klu`";
        $result = $this->db->query($sql);
        return $result->result_array();
    }
    
}
?>