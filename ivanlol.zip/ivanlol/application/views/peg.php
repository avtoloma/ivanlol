<div class="container">
    <div class="row">
        <div class="col-lg-12">
           <form method="post" action="main/reg_add">
    <h2>Регистрация</h2>
    <input type="hidden" name="csrf_token" value="ваш_сложный_токен_здесь">
    <div class="mb-3">
        <label for="login" class="form-label">Логин</label>
        <input type="text" name="login" class="form-control" id="login" aria-describedby="login" required>
    </div>
    <div class="mb-3">
        <label for="password" class="form-label">Пароль</label>
        <input type="password" name="password" class="form-control" id="password" required>
    </div>
    <div class="g-recaptcha" data-sitekey="ваш_ключ_сайта"></div>
    <button type="submit" class="btn btn-primary">Зарегистрироваться</button>
</form>
        </div>
    </div>
</div>