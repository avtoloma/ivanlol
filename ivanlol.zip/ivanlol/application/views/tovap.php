<div class="container">
    <div class="row">
        <div class="col-lg-12">
            <form method="post" action="tovap/tovap_add">
                <h2>товар</h2>
                <div class="mb-3">
                    <label for="naming" class="form-label">называние</label>
                    <input type="text" name="naming" class="form-control" id="login" aria-describedby="login">
                </div>
                <div class="mb-3">
                    <label for="password" class="form-label">возсрат</label>
                    <input type="text" name="age" class="form-control" id="age">
                </div>
                <div class="mb-3">
                    <label for="password" class="form-label">редкость</label>
                    <input type="text" name="rarity" class="form-control" id="rarity">
                </div>
                <div class="mb-3">
                    <label for="password" class="form-label">эпоха</label>
                    <input type="text" name="era" class="form-control" id="era">
                </div>
                <div class="mb-3">
                    <label for="text" class="form-label">цена</label>
                    <input type="text" name="price" class="form-control" id="price">
                </div>
                <button type="submit" class="btn btn-primary">Создан</button>
            </form>
        </div>
    </div>
</div>