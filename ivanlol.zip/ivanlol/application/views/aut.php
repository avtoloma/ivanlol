<div class="container">
    <div class="row">
        <div class="col-lg-12">
        <div class="container">
    <div class="row">
        <div class="col-lg-12">
            <form method="post" action="main/autch_add">
                <h2>Автострация</h2>
                <div class="mb-3">
                    <label for="login" class="form-label">Логин</label>
                    <input type="text" name="login" class="form-control" id="login" aria-describedby="login" required>
                </div>
                <div class="mb-3">
                    <label for="password" class="form-label">Пароль</label>
                    <input type="password" name="password" class="form-control" id="password" required>
                </div>
                <button type="submit" class="btn btn-primary">Вход</button>
            </form>
        </div>
    </div>
</div>
        </div>
    </div>
</div>