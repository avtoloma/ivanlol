<div class="container">
    <div class="row">
        <div class="col-lg-12">
            <h2 style="text-align: center;">доброе пожаловать</h2>
        </div>
    </div>
</div>