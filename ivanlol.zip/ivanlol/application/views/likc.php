<div class="container">
        <div class="row">
            <div class="col-lg-1"></div>
            <div class="col-lg-10">
                <div class="text-center">
                    <h1>Товар очет</h1>
                </div>
                <table class="table table-striped table-hover">
                    <thead>
                        <tr>
                            <th scope="col">№</th>
                            <th scope="col">называние</th>
                            <th scope="col">возсрат</th>
                            <th scope="col">редкость</th>
                            <th scope="col">эпоха</th>
                            <th scope="col">цена</th>
                            <th scope="col">Статус</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        foreach ($tovap as $row) {
                            echo '
                                  <tr><td>' . $row['id_klu'] .
                                '</td><td>' . $row['naming'] .
                                '</td><td>' . $row['age'] .
                                '</td><td>' . $row['rarity'] .
                                '</td><td>' . $row['era'] .
                                '</td><td>' . $row['price'] .
                                '</td><td>' . $row['staty'] .
                                '<td></td>
                                </tr>';
                        }?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</main>