<?php 
class Tovap extends CI_Controller
{
public  function tovap2() {
        $this->load->view('temp/header.php');
		$this->load->view('temp/navbar_b.php');
		$this->load->view('tovap.php');
		$this->load->view('temp/footer.php');
}
public function tovap_add()  {
    if (!empty($_POST)) {
			$naming = $_POST['naming'];
			$age = $_POST['age'];
			$rarity = $_POST['rarity'];
			$era = $_POST['era'];
			$price = $_POST['price'];
			$this->load->model('tovap_model');
			$this->tovap_model->tovap_insert($naming, $age, $rarity, $era, $price);
            redirect('tovap/tovap2');
		}
}
public  function lick() {
        $this->load->view('temp/header.php');
		$this->load->view('temp/navbar_b.php');
		$this->load->model('tovap_model');
		$data['tovap'] = $this->tovap_model->lick_add();
		$this->load->view('likc.php', $data);
		$this->load->view('temp/footer.php');
}
public  function lick2() {
        $this->load->view('temp/header.php');
		$this->load->view('temp/navbar_a.php');
		$this->load->model('tovap_model');
		$data['tovap'] = $this->tovap_model->lick_add();
		$this->load->view('likc2.php', $data);
		$this->load->view('temp/footer.php');
}
}
?>