<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Main extends CI_Controller
{
	public function index()
{
    $this->load->view('temp/header.php');
    if ($this->session->userdata('role')) {
        $role = $this->session->userdata('role');
        if ($role == 'Менеджер') {
            $this->load->view('temp/navbar_a.php');
        } elseif ($role == 'Клиент') {
            $this->load->view('temp/navbar_b.php');
        } else {
            $this->load->view('temp/navbar.php');
        }
    } else {
        $this->load->view('temp/navbar.php');
    }
    $this->load->view('main.php');
    $this->load->view('temp/footer.php');
}
	public function reg()
	{
		$this->load->view('temp/header.php');
		$this->load->view('temp/navbar.php');
		$this->load->view('peg.php');
		$this->load->view('temp/footer.php');
	}
	public function reg_add()
	{
		if (!empty($_POST)) {
			$login = $_POST['login'];
			$password = $_POST['password'];
			$this->load->model('users_model');
			$this->users_model->reg_insert($login, $password);
			redirect('main/reg');
		}
	}
	public function autch()
	{
		$this->load->view('temp/header.php');
		$this->load->view('temp/navbar.php');
		$this->load->view('aut.php');
		$this->load->view('temp/footer.php');
	}
	public function autch_add()
	{
		if (!empty($_POST)) {
			$login = $_POST['login'];
			$password = $_POST['password'];
			$this->load->model('users_model');
			$users = $this->users_model->autch_select($login, $password);
			if (!empty($users)) {
				$this->session->set_userdata($users);
			}
			redirect('main/index');
		}
	}
	public function logout()
	{
		$this->session->unset_userdata('role');
		redirect('main/index');
	}
}
?>